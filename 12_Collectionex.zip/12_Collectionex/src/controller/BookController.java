package controller;

import model.vo.Book;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BookController {


    List<Book> list = new ArrayList<>();




    public BookController(){
        list.add(new Book("자바의 정석", "남궁 성","기타",20000));
        list.add(new Book("쉽게 배우는 알고리즘", "문병로","기타", 15000));
        list.add(new Book("대화의 기술", "강보람", "인문", 17500));
        list.add(new Book("암 정복기", "박신우", "의료", 21000));
        }

    public void insertBook(Book bk){
        list.add(bk);
        //전달 받은 bk를 bookList에 추가
    }
    public ArrayList selectList(){
        return (ArrayList<Book>) list;
        // 해당 bookList의 주소 값 반환

    }


    public ArrayList searchBook(String keyword){

       /* // 검색 결과 리스트를 담아줄 리스트(ArrayList searchList) 선언 및 생성
        // 반복문을 통해 list의 책 중 책 명에 전달 받은 keyword가 포함되어있는 경우
        // searchList에 해당 책 추가하고 searchList 반환*/

        ArrayList<Book> searchList = new ArrayList<>();

        for(Book b : list){
            if(b.getTitle().contains(keyword)){
                System.out.println(searchList.add(b));
            }
            // * 내가 한 실수 : get() 대신 add()를 사용함 *

            // get()를 사용하는 이유 : 특정 키워드를 포함하는 책들을
            // 새로운 ArrayList에 추가하기 위해서 사용한다 list를 순회하면서 책 제목에 키워드가 포함된 책을 찾아
            // 'searchBook'에 추가하기 위해서이다
        }
        return searchList;
    }

    public Book deleteBook(String title, String author){

      /*  // 삭제된 도서를 담을 Book객체 (Book removeBook) 선언 및 null로 초기화
        // 반복문을 통해 bookList의 책 중 책 명이 전달 받은 title과 동일하고
        // 저자 명이 전달 받은 author와 동일한 경우 해당 인덱스 도서 삭제 후 빠져나감
        // 이 때 해당 인덱스 도서를 removeBook에 대입 후 removeBook 반환*/
        Book removeBook = null;

        for (int i = 0; i < list.size(); i++) {
            Book b = list.get(i); // list에서 책을 가져와 b에 할당
            if(b.getTitle().equals(title) && b.getAuthor().equals(author)){
            removeBook = list.remove(i);
            break;
            }
            // 내가 한 실수 contains를 사용함
            //
        }
        return removeBook;
    }

        // 강사님 실례지만 정렬은 필요가 없다고 생각이 들어 삭제 했습니다.
        public int ascBook(){

            int resuot = 1;

            list.sort(Book :: compareTo);
            // Book 클래스의 compareTo 메서드를 참조한다.
            // compareTo 메서드는 Book 객체들 간의 자연스러운 순서를 정의하는 메서드이다
            // list.sort(Book :: compareTo)는 list 요소들을
            // Book 클래스의 compareTo 메서드를 사용해 정렬하겠다는 의미

            return resuot;
    }
}








