package run;

import view.BookMenu;

public class Run {
    public static void main(String[] args) {


        BookMenu bm = new BookMenu();
        bm.mainMenu();


    }
}
