package com.kh.practice.student.view;

import com.kh.practice.student.controller.StudentController;
import com.kh.practice.student.model.vo.Student;

public class StudentMenu {
		
	StudentController ssm = new StudentController();
	
	
	 
	
	
	
	
	
	
	public StudentMenu (){
		
		System.out.println("=========학생 정보 출력=======" );
		
		
			Student[] aa = ssm.printStudent();
		
			System.out.println(aa[0].inform());
			System.out.println(aa[1].inform());
			System.out.println(aa[2].inform());
			System.out.println(aa[3].inform());
			System.out.println(aa[4].inform());
				
				
	System.out.println("=========학생 성적 출력=======");
		double[] a = ssm.avgScore();
		System.out.println("종합 점수 :" + (int) a[0]);
		System.out.println("종합 평균 :" + a[1]);
		
		
		
	

		
		
		System.out.println("=========성적 결과 출력=======");
		
				
		
		
	}

	
}
