package com.kh.practice.student.controller;

import java.util.Scanner;

import javax.net.ssl.SSLContext;
import javax.security.auth.Subject;

import com.kh.practice.student.model.vo.Student;

public class StudentController {
	
	Student[] sArr = new Student[5];
	
	Scanner sc = new Scanner(System.in);
	
	final int CUT_LINE = 60;
	
	
	
	 public StudentController() {
		 
		
	
				
				
				sArr[0] = new Student("최종군" ,"자바", 100 );
				sArr[1] = new Student("기다운", "자바", 50);
				sArr[2]	= new Student("김인창", "자바", 80);
				sArr[3]	= new Student("최종군", "SQL", 100);
				sArr[4]	= new Student("기다운", "SQL", 50);
				
			 	
				
				}
		 
	 
	 public Student[] printStudent(){
		 return sArr;
		 // 객체에 있는 데이터 반환
	 }
	 
	 
	 
	 public int sumScore() {
		 
		int total = 0;
		
		 for(int i = 0; i < sArr.length; i++) {
			total += sArr[i].getScore(); 
			 
		 }
		 
		 
		 return total;
				 
	 }
	 
	 public double[] avgScore() {
		 
		 
		 double[] darr = new double[2];
		 darr[0] = sumScore();
		 darr[1] = sumScore() / sArr.length;
		 
		 	
		 
		 
		 return darr;
	 } 
	
}
