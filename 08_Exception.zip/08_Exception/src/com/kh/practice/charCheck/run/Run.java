package com.kh.practice.charCheck.run;

import com.kh.practice.charCheck.view.CharacterMenu;

public class Run {

	public static void main(String[] agrs) {
		
	CharacterMenu m = new CharacterMenu();
	m.menu();
		
		
		
		
	}
}
