package com.kh.practice.student.run;

import com.kh.practice.student.view.StudentMenu;

public class Run {

	public static void main(String[] args) {
		
		StudentMenu sm = new StudentMenu();
			
		// 강사님 정말 너무 죄송합니다 제자가 못난 탓에 이 따위를 과제라고 제출을 하게 되었습니다 
		// 너무나도 송구스럽고 제 스스로가 한스럽습니다.
		// 부디 저를 용서하지말아주세요...
		// 앞으로 행실 똑바로 하겠습니다.........
		// 그리고 수업 중에 종종 카리나 언급해주셔서 감사합니다 
	}

}
