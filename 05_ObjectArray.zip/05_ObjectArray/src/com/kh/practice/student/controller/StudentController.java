package com.kh.practice.student.controller;

import java.util.Scanner;

import javax.security.auth.Subject;

import com.kh.practice.student.model.vo.Student;

public class StudentController {
	
	Student[] sArr = new Student[5];
	Scanner sc = new Scanner(System.in);
	
	final int CUT_LINE = 60;
	
	
	
	
	sArr[0] = new Student(1, "최종군");
	sArr[1] = new Student(2, "최종군");
	sArr[2]	= new Student(3, "최종군");
	sArr[3]	= new Student(4, "최종군");
	sArr[4]	= new Student(5, "최종군");
	
	 public StudentController() {
		 
		
				
				
			 	
				
				}
		 }
	 
	 public Student[] printStudent(){
		 return sArr;
	 }
	 
	 
	 
	 public int sumScore() {
		 return 1;	 }
	 
	 public double[] avgScore() {
		 
		 return avgScore();
	 } 
	
}
