package com.kh.practice.student.view;

import com.kh.practice.student.controller.StudentController;
import com.kh.practice.student.model.vo.Student;

public class StudentMenu {
		
	StudentController ssm = new StudentController();
	
	
	 
	
	
	
	
	
	
	public StudentMenu (){
		
		System.out.println("=========학생 정보 출력=======");
		ssm.printStudent();
		
		System.out.println("=========학생 성적 출력=======");
		ssm.avgScore();
		
		System.out.println("=========성적 결과 출력=======");
		
	}

	
}
